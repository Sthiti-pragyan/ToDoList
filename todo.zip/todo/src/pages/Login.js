// src/pages/Login.js
import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Box, Paper } from '@mui/material';
import { loginUser } from '../services/authService';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await loginUser({ email, password });
      localStorage.setItem('userEmail', res.data.email || email);
      navigate('/dashboard');
    } catch (err) {
      alert(err.response?.data?.message || 'Login failed');
    }
  };

  return (
    <Container maxWidth="sm">
      <Paper sx={{ padding: 4, marginTop: 6 }}>
        <Typography variant="h5" gutterBottom>Login</Typography>
        <TextField label="Email" fullWidth margin="normal" value={email} onChange={(e) => setEmail(e.target.value)} />
        <TextField type="password" label="Password" fullWidth margin="normal" value={password} onChange={(e) => setPassword(e.target.value)} />
        <Box mt={2}>
          <Button variant="contained" onClick={handleLogin}>Login</Button>
        </Box>
      </Paper>
    </Container>
  );
}
