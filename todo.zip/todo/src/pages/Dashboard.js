// src/pages/Dashboard.js
import React, { useState, useEffect } from 'react';
import { Container, TextField, Button, Typography, Box, Paper, Grid } from '@mui/material';
import { addTask, getTasks } from '../services/taskService';
import TaskCard from '../components/TaskCard';

export default function Dashboard() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [tasks, setTasks] = useState([]);
  const email = localStorage.getItem('userEmail');

  const handleAddTask = async () => {
    try {
      await addTask({ title, body, email });
      setTitle('');
      setBody('');
      fetchTasks();
    } catch (err) {
      alert('Error adding task');
    }
  };

  const fetchTasks = async () => {
    try {
      const res = await getTasks(email);
      setTasks(res.data || []);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <Container>
      <Paper sx={{ padding: 4, marginTop: 4 }}>
        <Typography variant="h5">Add New Task</Typography>
        <TextField label="Title" fullWidth margin="normal" value={title} onChange={(e) => setTitle(e.target.value)} />
        <TextField label="Description" fullWidth margin="normal" value={body} onChange={(e) => setBody(e.target.value)} />
        <Box mt={2}>
          <Button variant="contained" onClick={handleAddTask}>Add Task</Button>
        </Box>
      </Paper>

      <Grid container spacing={2} mt={2}>
        {tasks.map((task, idx) => (
          <Grid item xs={12} md={6} key={idx}>
            <TaskCard task={task} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
