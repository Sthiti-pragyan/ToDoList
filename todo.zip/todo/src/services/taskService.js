// src/services/taskService.js
import axios from 'axios';

const API_URL = 'http://localhost:4000/api/v2';

export const addTask = (data) => axios.post(`${API_URL}/addTask`, data);

// Future-proof
export const getTasks = (email) => axios.get(`${API_URL}/tasks?email=${email}`);
export const deleteTask = (id) => axios.delete(`${API_URL}/task/${id}`);
