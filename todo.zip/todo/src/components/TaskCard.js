// src/components/TaskCard.js
import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

export default function TaskCard({ task }) {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6">{task.title}</Typography>
        <Typography variant="body2">{task.body}</Typography>
      </CardContent>
    </Card>
  );
}
